#!/bin/bash
pdoc3 --force --html src/pnets/[a-z]*
